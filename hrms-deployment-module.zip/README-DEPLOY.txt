Deployment / System Update module — delta package
==================================================
Unzip over the HRMS project root; the folder structure already matches.

This is an INCREMENT on top of hrms-all-pending-changes.zip. It contains only
the Deployment module. Everything in the earlier package (the shift wave and the
Employee ID Card feature) is unchanged and is not repeated here.


1. NEW FILES (8)
----------------
  includes/deployer.php                 The engine. Root resolution, ZIP analysis,
                                        path validation, backup, atomic write,
                                        SHA-256 verification, rollback, locking,
                                        maintenance mode, database backup.
  install/add_deployment_module.sql     Migration: 2 tables + `deployment` perms.
  modules/deployment/index.php          Upload form + deployment history.
  modules/deployment/analyze.php        Upload handler + PREVIEW (writes nothing).
  modules/deployment/deploy.php         Lock -> backup -> write -> verify -> record.
  modules/deployment/rollback.php       Restore from the stored manifest.
  modules/deployment/details.php        Per-deployment file list + failure banner.
  .htaccess                             Blocks .sql/.zip/.bak downloads from the
                                        project root (a DB dump left there was
                                        being served over HTTP).


2. MODIFIED FILES (2)
---------------------
Full copies included, plus patches/deployment-module-changes.patch if your copy
has diverged:

    git apply patches/deployment-module-changes.patch

  includes/bootstrap.php   +1 require for deployer.php, plus the maintenance-mode
                           gate. Super Admins and the deployment module are never
                           locked out, so a failed deployment can always be rolled
                           back.
  includes/header.php      One nav item, "System Update", under Settings, guarded
                           by can('deployment','view').

NOTHING ELSE was touched.


3. RUN THE MIGRATION
--------------------
Idempotent — safe to re-run. From the project root:

    php -r "require 'config/database.php';
      $sql = file_get_contents('install/add_deployment_module.sql');
      $sql = implode(chr(10), array_filter(preg_split('/\r?\n/', $sql),
             fn($l) => !preg_match('/^\s*--/', $l)));
      $db = db();
      foreach (array_filter(array_map('trim', explode(';', $sql))) as $s) { $db->exec($s); }
      echo 'done';"

Creates:
  deployments        deployment history (id, user, package, counts, status, backup)
  deployment_files   per-file record (action, before/after size + SHA-256)
  permissions        deployment: view / deploy / rollback  -> Super Admin ONLY

The audit trail reuses the existing activity_logs table.


4. IMPORTANT — THIS MODULE CANNOT DEPLOY ITSELF
-----------------------------------------------
modules/deployment/ and includes/deployer.php are on the PROTECTED list, so a
package can never overwrite them. That is deliberate: a bad package must not be
able to break the tool you would use to recover.

Consequence: THIS package must be installed by hand (unzip + run the migration).
Everything after it can go through the module.


5. WHAT IT DOES
---------------
Settings -> System Update, Super Admin only.

  Upload ZIP -> Analyze -> PREVIEW (nothing written yet) -> Backup & Deploy
             -> per-file SHA-256 verification -> recorded in history
             -> Rollback available

Preview classifies every entry as ADD / UPDATE / SKIP / PROTECTED, and flags
.sql files as DB CHANGE. Refused automatically:
  • path traversal (../), absolute paths, C:\ paths, UNC, php:// wrappers
  • anything resolving outside the application root
  • protected paths: config/, .env, .git/, vendor/, storage/, uploads/,
    and the deployment module itself
  • file types not on the whitelist (.phtml, .phar, .sh, .exe … refused)

Backups go to <root>/../hrms-deploy-data/backups/DEP-YYYYMMDD-HHMMSS/ (falling
back to storage/deployments/ when the parent is not writable), mirroring the
original tree, with a _manifest.json recording before/after hashes. Rollback
restores UPDATEs from the backup and DELETES files that were ADDs.

SQL files are installed as files AND offered for execution behind a separate
confirmation; a database backup is taken before any statement runs.


6. TESTED
---------
  End-to-end suite   41 assertions, 0 failures
  Concurrency suite  18 assertions, 0 failures

Covered: ADD, UPDATE, backup fidelity, SHA-256 verification, both rollback
branches (restore-over-existing and delete-if-new), traversal/protected/file-type
refusal, SQL never auto-running, the deployment lock, and the audit trail.

NOT yet exercised end to end:
  • SQL execution with the tick-box (the earlier attempt failed on a stale test
    table, and .sql handling changed afterwards)
  • LIVE mode — the red banner and typed DEPLOY confirmation only appear when
    APP_ENV=production
  • A full-size package (everything tested has been small)


7. SECURITY NOTE — READ BEFORE ENABLING ON LIVE
------------------------------------------------
This module writes PHP into the application root. That is remote code execution
BY DESIGN, restricted to a Super Admin. The controls above stop accidents and
hostile archives; they cannot protect against a compromised Super Admin account.

  • Keep the `deployment` permission on Super Admin only.
  • config/app.php can define DEPLOYMENT_ENABLED=false to disable the module
    entirely between releases.
  • Deployment storage is hardened (.htaccess + web.config + index.html) because
    on a stock XAMPP layout the parent of the app IS the document root.
