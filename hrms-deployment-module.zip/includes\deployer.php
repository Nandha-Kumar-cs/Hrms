<?php
/**
 * MagDyn HRMS — Deployment engine
 * ────────────────────────────────
 * Everything the System Update module needs to take a delta ZIP and apply it to
 * THIS installation, safely, in both local and live environments.
 *
 * There is no HTML here — the pages under modules/deployment/ call into this.
 *
 * SECURITY NOTE (read before changing anything below)
 * ---------------------------------------------------
 * This file writes PHP into the application root. That is remote code execution
 * by design, restricted to a Super Admin. The controls here exist to stop
 * ACCIDENTS and malformed/hostile archives; they cannot protect against a
 * compromised Super Admin account. Two rules must never be relaxed:
 *
 *   1. Every destination is canonicalised and proven to sit inside HRMS_ROOT
 *      before anything is written (deploy_safe_target).
 *   2. The protected list (deploy_is_protected) is checked on every entry, and
 *      it includes this module itself so a bad package cannot brick the
 *      deployer that would be used to recover.
 */

// ─── Configuration ────────────────────────────────────────────────────────────

/** Master kill-switch. Define DEPLOYMENT_ENABLED=false in config/app.php to
 *  disable the module entirely (e.g. on live between releases). */
if (!defined('DEPLOYMENT_ENABLED')) define('DEPLOYMENT_ENABLED', true);

/** Largest package accepted, in bytes. */
if (!defined('DEPLOYMENT_MAX_ZIP_BYTES')) define('DEPLOYMENT_MAX_ZIP_BYTES', 64 * 1024 * 1024);

/** Largest single file inside a package. */
if (!defined('DEPLOYMENT_MAX_FILE_BYTES')) define('DEPLOYMENT_MAX_FILE_BYTES', 16 * 1024 * 1024);

/** Most entries a package may contain (zip-bomb guard). */
if (!defined('DEPLOYMENT_MAX_ENTRIES')) define('DEPLOYMENT_MAX_ENTRIES', 3000);

/** A lock older than this is treated as stale and broken. */
if (!defined('DEPLOYMENT_LOCK_TTL')) define('DEPLOYMENT_LOCK_TTL', 900);   // 15 min

/**
 * Extensions a package may install.
 *
 * `.htaccess` is NOT an extension — it is handled separately by
 * deploy_extension_allowed(), because real delta packages legitimately carry
 * per-directory .htaccess files (the QR portal's rewrite rule is one) and a
 * pure extension whitelist would silently skip them and half-install a feature.
 */
function deploy_allowed_extensions(): array
{
    return [
        'php', 'css', 'js', 'html', 'htm', 'json', 'xml', 'sql',
        'md', 'txt', 'csv', 'svg', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'ico',
        'woff', 'woff2', 'ttf', 'eot', 'map', 'pdf',
    ];
}

/** Basenames allowed even though they have no (or a dot-leading) extension. */
function deploy_allowed_basenames(): array
{
    return ['.htaccess', 'web.config', '.gitignore', 'robots.txt'];
}

/**
 * Paths that must never be written by a package, relative to HRMS_ROOT and
 * forward-slashed. A trailing slash means "this directory and everything in it".
 *
 * config/ is protected in full, not just database.php: config/app.php holds
 * BASE_URL, which differs per environment — deploying it would repoint a live
 * install at the developer's machine.
 */
function deploy_protected_paths(): array
{
    return [
        'config/',                      // DB credentials AND per-environment BASE_URL
        '.env',
        '.git/',
        'vendor/',
        'storage/',                     // uploads, backups, packages
        'uploads/',                     // employee photos & documents
        'includes/deployer.php',        // this engine
        'modules/deployment/',          // the module's own pages
        'install/.htaccess',
    ];
}

// ─── Environment & paths ──────────────────────────────────────────────────────

/**
 * The HRMS application root, canonicalised.
 *
 * Derived from BASE_PATH, which config/app.php already defines as
 * dirname(__DIR__) — i.e. the directory holding config/. Nothing is hard-coded,
 * so the same code resolves correctly under XAMPP and on a live host.
 */
function deploy_root(): string
{
    static $root = null;
    if ($root !== null) return $root;
    $r = realpath(BASE_PATH);
    if ($r === false) {
        throw new RuntimeException('Application root could not be resolved.');
    }
    return $root = rtrim(str_replace('\\', '/', $r), '/');
}

/** 'LIVE' or 'LOCAL', from the app's own APP_ENV — never guessed from the URL. */
function deploy_env(): string
{
    $env = strtolower((string) (defined('APP_ENV') ? APP_ENV : 'production'));
    return in_array($env, ['local', 'development', 'dev', 'testing'], true) ? 'LOCAL' : 'LIVE';
}

function deploy_is_live(): bool { return deploy_env() === 'LIVE'; }

/**
 * Where packages, staging areas and backups live.
 *
 * Prefers a sibling of the application root, so nothing is reachable over HTTP
 * at all. Falls back to storage/deployments/ (already hardened by
 * storage/.htaccess, which disables the PHP engine) when the parent directory
 * is not writable — the common case on shared hosting.
 */
function deploy_storage_dir(): string
{
    static $dir = null;
    if ($dir !== null) return $dir;

    $root   = deploy_root();
    $parent = dirname($root);
    $outside = $parent . '/hrms-deploy-data';

    $chosen = null;
    if (is_dir($outside) || (is_writable($parent) && @mkdir($outside, 0700, true))) {
        if (is_writable($outside)) $chosen = $outside;
    }
    if ($chosen === null) {
        $inside = $root . '/storage/deployments';
        if (!is_dir($inside)) @mkdir($inside, 0700, true);
        $chosen = $inside;
    }

    deploy_harden_dir($chosen);
    return $dir = $chosen;
}

/**
 * Make a storage directory unreachable over HTTP.
 *
 * Being outside HRMS_ROOT is not the same as being outside the DOCUMENT ROOT:
 * on a stock XAMPP layout the parent of the app IS htdocs, so the preferred
 * location would otherwise be downloadable at /hrms-deploy-data/. Package ZIPs,
 * file backups and database dumps all live here, so this is written every time
 * rather than assumed.
 */
function deploy_harden_dir(string $dir): void
{
    if (!is_dir($dir)) return;

    $ht = $dir . '/.htaccess';
    if (!is_file($ht)) {
        @file_put_contents($ht, implode("\n", [
            '# Deployment storage — packages, file backups and database dumps.',
            '# Never reachable over HTTP, and never executable.',
            '<IfModule mod_authz_core.c>',
            '    Require all denied',
            '</IfModule>',
            '<IfModule !mod_authz_core.c>',
            '    Order allow,deny',
            '    Deny from all',
            '</IfModule>',
            'php_flag engine off',
            'RemoveHandler .php .phtml .php3 .php4 .php5 .php7 .phar',
            'RemoveType .php .phtml .php3 .php4 .php5 .php7 .phar',
            'Options -Indexes',
            '',
        ]));
    }
    // Belt and braces for servers that ignore .htaccess.
    if (!is_file($dir . '/index.html')) @file_put_contents($dir . '/index.html', '');
    if (!is_file($dir . '/web.config')) {
        @file_put_contents($dir . '/web.config',
            "<?xml version=\"1.0\"?>\n<configuration><system.webServer><security>"
          . "<authorization><deny users=\"*\" /></authorization></security>"
          . "</system.webServer></configuration>\n");
    }
}

function deploy_packages_dir(): string { return deploy_storage_dir() . '/packages'; }
function deploy_staging_dir(): string  { return deploy_storage_dir() . '/staging'; }
function deploy_backups_dir(): string  { return deploy_storage_dir() . '/backups'; }

/** True when the storage area is usable; the UI blocks deployment otherwise. */
function deploy_storage_ready(): bool
{
    foreach ([deploy_packages_dir(), deploy_staging_dir(), deploy_backups_dir()] as $d) {
        if (!is_dir($d) && !@mkdir($d, 0700, true)) return false;
        if (!is_writable($d)) return false;
    }
    return true;
}

// ─── Path safety ──────────────────────────────────────────────────────────────

/**
 * Normalise a ZIP entry name to a safe relative path, or null to reject it.
 *
 * Rejects, in order: absolute POSIX paths, Windows drive paths, UNC paths,
 * stream wrappers, NUL bytes, and any `..` segment. Resolving `.`/`..`
 * textually here is a first line of defence only — deploy_safe_target() does
 * the authoritative filesystem-level check afterwards.
 */
function deploy_normalize_entry(string $name): ?string
{
    $p = str_replace('\\', '/', trim($name));

    if ($p === '' || strpos($p, "\0") !== false)   return null;   // NUL injection
    if (preg_match('#^[a-zA-Z]:#', $p))            return null;   // C:\Windows\...
    if (strncmp($p, '//', 2) === 0)                return null;   // UNC \\server\share
    if ($p[0] === '/')                             return null;   // /etc/passwd
    if (preg_match('#^[a-zA-Z][a-zA-Z0-9+.-]*://#', $p)) return null;  // php://, http://

    $out = [];
    foreach (explode('/', $p) as $seg) {
        if ($seg === '' || $seg === '.') continue;
        if ($seg === '..') return null;                            // ../../config.php
        $out[] = $seg;
    }
    if (!$out) return null;

    $rel = implode('/', $out);
    return strlen($rel) > 500 ? null : $rel;
}

/**
 * Absolute destination for a relative path, proven to be inside HRMS_ROOT.
 * Returns null if it would land anywhere else.
 *
 * The check canonicalises the nearest EXISTING ancestor (the file itself may not
 * exist yet) and then requires the result to be the root or a descendant of it.
 * That is what actually defeats symlinked directories; a string comparison on
 * the un-resolved path does not.
 */
function deploy_safe_target(string $rel): ?string
{
    $rel = deploy_normalize_entry($rel);
    if ($rel === null) return null;

    $root   = deploy_root();
    $target = $root . '/' . $rel;

    $probe = $target;
    while (!file_exists($probe)) {
        $up = dirname($probe);
        if ($up === $probe) return null;
        $probe = $up;
    }
    $real = realpath($probe);
    if ($real === false) return null;
    $real = rtrim(str_replace('\\', '/', $real), '/');

    // Windows paths are case-insensitive; POSIX ones are not.
    $ci  = DIRECTORY_SEPARATOR === '\\';
    $a   = $ci ? strtolower($real) : $real;
    $b   = $ci ? strtolower($root) : $root;
    if ($a !== $b && strncmp($a, $b . '/', strlen($b) + 1) !== 0) return null;

    return $target;
}

/** True if the package must not touch this path. */
function deploy_is_protected(string $rel): bool
{
    $rel = ltrim(str_replace('\\', '/', $rel), '/');
    $cmp = DIRECTORY_SEPARATOR === '\\' ? strtolower($rel) : $rel;

    foreach (deploy_protected_paths() as $p) {
        $p = DIRECTORY_SEPARATOR === '\\' ? strtolower($p) : $p;
        if (substr($p, -1) === '/') {
            if (strncmp($cmp, $p, strlen($p)) === 0) return true;      // inside dir
        } elseif ($cmp === $p) {
            return true;                                              // exact file
        }
    }
    return false;
}

/** True if the file's extension (or basename) is on the whitelist. */
function deploy_extension_allowed(string $rel): bool
{
    $base = basename($rel);
    if (in_array($base, deploy_allowed_basenames(), true)) return true;
    if (strpos($base, '.') === false) return false;                   // no extension

    $ext = strtolower((string) pathinfo($base, PATHINFO_EXTENSION));
    if ($ext === '') return false;

    // Never accept anything that could be executed by a mis-configured server
    // even if it somehow reached the whitelist.
    if (in_array($ext, ['phtml', 'phar', 'phps', 'pht', 'cgi', 'pl', 'py', 'sh', 'exe', 'bat', 'com'], true)) {
        return false;
    }
    return in_array($ext, deploy_allowed_extensions(), true);
}

// ─── Deployment id & lock ─────────────────────────────────────────────────────

function deploy_new_id(): string
{
    return 'DEP-' . date('Ymd-His');
}

/**
 * Acquire the global deployment lock. Returns a handle to pass to
 * deploy_unlock(), or null when another deployment holds it.
 *
 * Uses flock(), so the lock is released by the OS even if PHP dies mid-request.
 * A lock file whose mtime is older than DEPLOYMENT_LOCK_TTL is treated as stale
 * (a crashed run) and reclaimed.
 */
function deploy_lock()
{
    $path = deploy_storage_dir() . '/deploy.lock';

    if (is_file($path) && (time() - (int) @filemtime($path)) > DEPLOYMENT_LOCK_TTL) {
        @unlink($path);                                   // stale — reclaim
    }

    $fh = @fopen($path, 'c+');
    if (!$fh) return null;

    if (!flock($fh, LOCK_EX | LOCK_NB)) {                 // someone else is deploying
        fclose($fh);
        return null;
    }

    /* Who holds the lock goes in a SEPARATE file.
     * On Windows flock() is a MANDATORY lock, so while the lock is held the
     * lock file itself cannot be read at all ("Permission denied") — which
     * would leave the "deployment in progress" banner unable to name anyone.
     * POSIX flock is advisory and would read fine, but the sidecar keeps both
     * platforms behaving identically. */
    @file_put_contents($path . '.info', json_encode([
        'pid'  => function_exists('getmypid') ? getmypid() : null,
        'user' => current_user()['name'] ?? 'unknown',
        'at'   => date('c'),
    ]));

    @touch($path);
    return $fh;
}

/**
 * Release the lock. Safe to call more than once, and safe to call with a handle
 * that has already been closed — the callers register this as a shutdown
 * function AND may call it directly.
 */
function deploy_unlock($fh): void
{
    static $released = false;
    if ($released) return;
    $released = true;

    if (is_resource($fh)) {
        @flock($fh, LOCK_UN);
        @fclose($fh);
    }
    $path = deploy_storage_dir() . '/deploy.lock';
    @unlink($path);
    @unlink($path . '.info');
}

/**
 * Release the lock (and clear maintenance mode) no matter how the script ends.
 *
 * A `finally` block is NOT enough here: redirect() calls exit(), and exit()
 * bypasses finally in PHP, which would leave the lock file behind and block
 * every later deployment until the TTL expired. Shutdown functions DO run on
 * exit(), so the cleanup is registered the moment the lock is taken.
 */
function deploy_register_cleanup($fh, bool &$maintenanceOn): void
{
    register_shutdown_function(function () use ($fh, &$maintenanceOn) {
        if ($maintenanceOn) deploy_maintenance_disable();
        deploy_unlock($fh);
    });
}

/**
 * Details of the current lock holder, for the "already in progress" message.
 * Returns null when no deployment is running.
 *
 * Reads the sidecar rather than the lock file itself — see deploy_lock() for
 * why the lock file is unreadable while held on Windows.
 */
function deploy_lock_info(): ?array
{
    $path = deploy_storage_dir() . '/deploy.lock';
    if (!is_file($path)) return null;

    // A lock past its TTL is stale (a crashed run) — report it as not running,
    // matching what deploy_lock() will do on the next attempt.
    if ((time() - (int) @filemtime($path)) > DEPLOYMENT_LOCK_TTL) return null;

    $j = json_decode((string) @file_get_contents($path . '.info'), true);
    return is_array($j) ? $j : [];
}

// ─── Maintenance mode ─────────────────────────────────────────────────────────
// A flag file rather than a DB row, so it still works if a deployment breaks the
// database layer. bootstrap.php checks it; Super Admins are never locked out.

function deploy_maintenance_file(): string { return deploy_root() . '/storage/maintenance.flag'; }
function deploy_maintenance_on(): bool     { return is_file(deploy_maintenance_file()); }

function deploy_maintenance_enable(string $by): void
{
    @file_put_contents(deploy_maintenance_file(), json_encode(['by' => $by, 'at' => date('c')]));
}
function deploy_maintenance_disable(): void { @unlink(deploy_maintenance_file()); }

// ─── Analysis ─────────────────────────────────────────────────────────────────

/**
 * Open and validate a ZIP, returning what a deployment WOULD do. Nothing is
 * written to the application root by this function.
 *
 * @return array{ok:bool,error:?string,entries:array,summary:array,has_sql:bool}
 *   entries[] = [rel, action, reason, size, sha256, size_before, sha256_before]
 *   action ∈ ADD | UPDATE | SKIP | PROTECTED | SQL
 */
function deploy_analyze(string $zipPath): array
{
    $out = ['ok' => false, 'error' => null, 'entries' => [],
            'summary' => ['total' => 0, 'add' => 0, 'update' => 0, 'skip' => 0, 'protected' => 0, 'sql' => 0],
            'has_sql' => false];

    if (!class_exists('ZipArchive')) {
        $out['error'] = 'The PHP zip extension is not available on this server.';
        return $out;
    }

    $zip = new ZipArchive();
    $rc  = $zip->open($zipPath, ZipArchive::CHECKCONS);   // integrity check
    if ($rc !== true) {
        $out['error'] = 'The package is not a readable ZIP archive (code ' . $rc . ').';
        return $out;
    }
    if ($zip->numFiles > DEPLOYMENT_MAX_ENTRIES) {
        $zip->close();
        $out['error'] = 'The package contains too many entries (' . $zip->numFiles . ').';
        return $out;
    }

    $root = deploy_root();

    for ($i = 0; $i < $zip->numFiles; $i++) {
        $st = $zip->statIndex($i);
        if ($st === false) continue;

        $raw = (string) $st['name'];
        if (substr($raw, -1) === '/') continue;            // directory entry

        $entry = ['raw' => $raw, 'rel' => null, 'action' => 'SKIP', 'reason' => '',
                  'size' => (int) $st['size'], 'sha256' => null,
                  'size_before' => null, 'sha256_before' => null, 'is_sql' => false];

        $rel = deploy_normalize_entry($raw);
        if ($rel === null) {
            $entry['reason'] = 'Unsafe path — rejected';
            $out['entries'][] = $entry; $out['summary']['skip']++; $out['summary']['total']++;
            continue;
        }
        $entry['rel'] = $rel;

        // Reject before extracting anything.
        if (deploy_safe_target($rel) === null) {
            $entry['action'] = 'SKIP'; $entry['reason'] = 'Resolves outside the application root';
            $out['entries'][] = $entry; $out['summary']['skip']++; $out['summary']['total']++;
            continue;
        }
        if (deploy_is_protected($rel)) {
            $entry['action'] = 'PROTECTED'; $entry['reason'] = 'Protected path';
            $out['entries'][] = $entry; $out['summary']['protected']++; $out['summary']['total']++;
            continue;
        }
        if (!deploy_extension_allowed($rel)) {
            $entry['action'] = 'SKIP'; $entry['reason'] = 'File type not permitted';
            $out['entries'][] = $entry; $out['summary']['skip']++; $out['summary']['total']++;
            continue;
        }
        if ($entry['size'] > DEPLOYMENT_MAX_FILE_BYTES) {
            $entry['action'] = 'SKIP'; $entry['reason'] = 'File exceeds the size limit';
            $out['entries'][] = $entry; $out['summary']['skip']++; $out['summary']['total']++;
            continue;
        }

        $data = $zip->getFromIndex($i);
        if ($data === false) {
            $entry['action'] = 'SKIP'; $entry['reason'] = 'Entry could not be read';
            $out['entries'][] = $entry; $out['summary']['skip']++; $out['summary']['total']++;
            continue;
        }
        $entry['sha256'] = hash('sha256', $data);
        $entry['size']   = strlen($data);

        /* A .sql entry is BOTH a file and a database change:
         *   • it is installed like any other file, so migrations land in
         *     install/ permanently and are backed up / rolled back normally;
         *   • and it is offered for execution behind a separate confirmation.
         * Treating it as "database only" meant packaged migrations were run but
         * never filed, so the next developer had no record of them. */
        if (strtolower((string) pathinfo($rel, PATHINFO_EXTENSION)) === 'sql') {
            $entry['is_sql'] = true;
            $entry['reason'] = 'Database change — installed as a file; run requires separate confirmation';
            $out['has_sql']  = true;
            $out['summary']['sql']++;
        }

        $abs = $root . '/' . $rel;
        if (is_file($abs)) {
            $entry['size_before']   = (int) filesize($abs);
            $entry['sha256_before'] = hash_file('sha256', $abs) ?: null;
            if ($entry['sha256_before'] === $entry['sha256']) {
                $entry['action'] = 'SKIP';
                $entry['reason'] = 'Identical to the installed file';
                $out['summary']['skip']++;
            } else {
                $entry['action'] = 'UPDATE';
                $out['summary']['update']++;
            }
        } else {
            $entry['action'] = 'ADD';
            $out['summary']['add']++;
        }
        $out['summary']['total']++;
        $out['entries'][] = $entry;
    }

    $zip->close();

    usort($out['entries'], function ($a, $b) {
        $order = ['UPDATE' => 0, 'ADD' => 1, 'SQL' => 2, 'PROTECTED' => 3, 'SKIP' => 4];
        $c = ($order[$a['action']] ?? 9) <=> ($order[$b['action']] ?? 9);
        return $c !== 0 ? $c : strcmp((string) $a['rel'], (string) $b['rel']);
    });

    // Does applying this package actually change anything on disk?
    $out['has_file_changes'] = ($out['summary']['add'] + $out['summary']['update']) > 0;

    $out['ok'] = true;
    return $out;
}

// ─── Execution ────────────────────────────────────────────────────────────────

/** Recursively delete a directory (used for staging cleanup only). */
function deploy_rmdir(string $dir): void
{
    if (!is_dir($dir)) return;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $f) { $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname()); }
    @rmdir($dir);
}

/** Write $data to $target atomically (temp file + rename on the same volume). */
function deploy_write_atomic(string $target, string $data): bool
{
    $dir = dirname($target);
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) return false;

    $tmp = $target . '.deploy-' . bin2hex(random_bytes(4)) . '.tmp';
    if (@file_put_contents($tmp, $data) === false) { @unlink($tmp); return false; }
    if (!@rename($tmp, $target)) {                       // Windows: rename over an
        @unlink($target);                                // existing file can fail
        if (!@rename($tmp, $target)) { @unlink($tmp); return false; }
    }
    return true;
}

/**
 * Apply a package.
 *
 * Order is: backup every file that will change → write → verify each write by
 * SHA-256 → on ANY failure, restore from the backup in reverse and report.
 *
 * @return array{ok:bool,deployment_id:string,error:?string,files:array,rolled_back:bool}
 */
function deploy_execute(string $zipPath, string $packageName, array $analysis, string $deploymentId): array
{
    $root      = deploy_root();
    $backupDir = deploy_backups_dir() . '/' . $deploymentId;
    $result    = ['ok' => false, 'deployment_id' => $deploymentId, 'error' => null,
                  'files' => [], 'rolled_back' => false, 'backup_dir' => $backupDir];

    // Never overwrite an existing backup — a repeated id means something is wrong.
    if (is_dir($backupDir)) {
        $result['error'] = 'A backup for this deployment id already exists.';
        return $result;
    }
    if (!@mkdir($backupDir, 0700, true)) {
        $result['error'] = 'The backup directory could not be created.';
        return $result;
    }

    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CHECKCONS) !== true) {
        $result['error'] = 'The package could not be reopened for deployment.';
        return $result;
    }

    $applied  = [];          // [rel, action, backup(abs|null)] in write order
    $manifest = [];
    $failure  = null;

    foreach ($analysis['entries'] as $e) {
        if (!in_array($e['action'], ['ADD', 'UPDATE'], true)) continue;

        $rel = $e['rel'];

        // Re-validate at write time; never trust the analysis alone.
        $target = deploy_safe_target($rel);
        if ($target === null || deploy_is_protected($rel) || !deploy_extension_allowed($rel)) {
            $failure = ['rel' => $rel, 'msg' => 'Failed a safety check at write time'];
            break;
        }

        $data = $zip->getFromName($e['raw']);
        if ($data === false) {
            $failure = ['rel' => $rel, 'msg' => 'Could not read the file from the package'];
            break;
        }
        if (hash('sha256', $data) !== $e['sha256']) {
            $failure = ['rel' => $rel, 'msg' => 'Package contents changed during deployment'];
            break;
        }

        // 1. Back up the existing file, preserving structure.
        $backupPath = null;
        if ($e['action'] === 'UPDATE' && is_file($target)) {
            $backupPath = $backupDir . '/' . $rel;
            if (!is_dir(dirname($backupPath)) && !@mkdir(dirname($backupPath), 0700, true)) {
                $failure = ['rel' => $rel, 'msg' => 'Backup directory could not be created'];
                break;
            }
            if (!@copy($target, $backupPath)) {
                $failure = ['rel' => $rel, 'msg' => 'Existing file could not be backed up'];
                break;
            }
        }

        // 2. Write.
        if (!deploy_write_atomic($target, $data)) {
            $failure = ['rel' => $rel, 'msg' => 'File could not be written'];
            break;
        }

        // 3. Verify: exists, readable, size, SHA-256.
        clearstatcache(true, $target);
        if (!is_file($target) || !is_readable($target)) {
            $failure = ['rel' => $rel, 'msg' => 'File is missing or unreadable after writing'];
            break;
        }
        if ((int) filesize($target) !== strlen($data)) {
            $failure = ['rel' => $rel, 'msg' => 'Size mismatch after writing'];
            break;
        }
        $after = hash_file('sha256', $target);
        if ($after !== $e['sha256']) {
            $failure = ['rel' => $rel, 'msg' => 'Checksum mismatch after writing'];
            break;
        }

        $applied[]  = ['rel' => $rel, 'action' => $e['action'], 'backup' => $backupPath];
        $manifest[] = ['rel' => $rel, 'action' => $e['action'],
                       'sha256_before' => $e['sha256_before'], 'sha256_after' => $after,
                       'size_before' => $e['size_before'], 'size_after' => strlen($data)];
        $result['files'][] = ['rel' => $rel, 'action' => $e['action'], 'status' => 'OK',
                              'size_before' => $e['size_before'], 'size_after' => strlen($data),
                              'sha256_before' => $e['sha256_before'], 'sha256_after' => $after];
    }

    $zip->close();

    // The manifest is what rollback reads; write it even on failure.
    @file_put_contents($backupDir . '/_manifest.json', json_encode([
        'deployment_id' => $deploymentId,
        'package'       => $packageName,
        'created_at'    => date('c'),
        'environment'   => deploy_env(),
        'files'         => $manifest,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

    if ($failure !== null) {
        $restored = deploy_restore_files($applied, $backupDir);
        $result['error']       = 'Failed on ' . $failure['rel'] . ': ' . $failure['msg'];
        $result['failed_file'] = $failure['rel'];
        $result['rolled_back'] = $restored;
        return $result;
    }

    $result['ok'] = true;
    return $result;
}

/**
 * Undo a set of applied writes, newest first.
 * UPDATEs are copied back from the backup; ADDs are removed, because they had no
 * previous version — that distinction is why the manifest records the action.
 */
function deploy_restore_files(array $applied, string $backupDir): bool
{
    $allOk = true;
    foreach (array_reverse($applied) as $a) {
        $target = deploy_safe_target($a['rel']);
        if ($target === null) { $allOk = false; continue; }

        if ($a['action'] === 'ADD') {
            if (is_file($target) && !@unlink($target)) $allOk = false;
            continue;
        }
        $backup = $a['backup'] ?? ($backupDir . '/' . $a['rel']);
        if (!is_file($backup)) { $allOk = false; continue; }
        if (!@copy($backup, $target)) { $allOk = false; continue; }

        clearstatcache(true, $target);
        if (hash_file('sha256', $target) !== hash_file('sha256', $backup)) $allOk = false;
    }
    return $allOk;
}

/**
 * Roll a completed deployment back using its stored manifest.
 * @return array{ok:bool,error:?string,restored:int,failed:int}
 */
function deploy_rollback_deployment(string $deploymentId): array
{
    $out = ['ok' => false, 'error' => null, 'restored' => 0, 'failed' => 0, 'nothing_to_do' => false];

    $backupDir = deploy_backups_dir() . '/' . basename($deploymentId);
    $manifest  = $backupDir . '/_manifest.json';
    if (!is_file($manifest)) {
        $out['error'] = 'No backup manifest exists for this deployment.';
        return $out;
    }
    $data = json_decode((string) file_get_contents($manifest), true);
    if (!is_array($data)) {
        $out['error'] = 'The backup manifest could not be read.';
        return $out;
    }

    /* A deployment that changed nothing — every file in the package was already
     * identical, protected or not permitted — has an empty manifest. That is a
     * normal outcome, not a failure, so say so rather than reporting
     * "0 restored, 0 failed" as if something went wrong. */
    if (empty($data['files'])) {
        $out['ok']            = true;
        $out['nothing_to_do'] = true;
        return $out;
    }

    foreach (array_reverse($data['files']) as $f) {
        $rel    = (string) ($f['rel'] ?? '');
        $target = deploy_safe_target($rel);
        if ($rel === '' || $target === null || deploy_is_protected($rel)) { $out['failed']++; continue; }

        if (($f['action'] ?? '') === 'ADD') {
            if (!is_file($target) || @unlink($target)) $out['restored']++; else $out['failed']++;
            continue;
        }

        $backup = $backupDir . '/' . $rel;
        if (!is_file($backup)) { $out['failed']++; continue; }

        $bytes = @file_get_contents($backup);
        if ($bytes === false || !deploy_write_atomic($target, $bytes)) { $out['failed']++; continue; }

        clearstatcache(true, $target);
        if (hash_file('sha256', $target) === hash('sha256', $bytes)) $out['restored']++;
        else $out['failed']++;
    }

    $out['ok'] = ($out['failed'] === 0);
    if (!$out['ok']) $out['error'] = $out['failed'] . ' file(s) could not be restored.';
    return $out;
}

// ─── Database backup (only used when SQL is executed) ─────────────────────────

/**
 * Dump the database before running any packaged SQL.
 * Prefers mysqldump; falls back to a PDO-driven dump so the feature still works
 * where exec() is disabled (most shared hosting).
 *
 * @return array{ok:bool,path:?string,error:?string,method:string}
 */
function deploy_db_backup(string $deploymentId): array
{
    $dir = deploy_storage_dir() . '/db';
    if (!is_dir($dir) && !@mkdir($dir, 0700, true)) {
        return ['ok' => false, 'path' => null, 'error' => 'Backup directory could not be created.', 'method' => 'none'];
    }
    $path = $dir . '/' . $deploymentId . '.sql';

    // 1) mysqldump, when we are allowed to run it.
    if (function_exists('exec') && !in_array('exec', array_map('trim', explode(',', (string) ini_get('disable_functions'))), true)) {
        foreach ([
            'C:/xampp8.2/mysql/bin/mysqldump.exe',
            'C:/xampp/mysql/bin/mysqldump.exe',
            'mysqldump',
        ] as $bin) {
            $cmd = escapeshellarg($bin)
                 . ' -h ' . escapeshellarg(DB_HOST)
                 . ' -P ' . escapeshellarg((string) DB_PORT)
                 . ' -u ' . escapeshellarg(DB_USER)
                 . (DB_PASS !== '' ? ' -p' . escapeshellarg(DB_PASS) : '')
                 . ' --single-transaction --add-drop-table --default-character-set=utf8mb4 '
                 . escapeshellarg(DB_NAME)
                 . ' > ' . escapeshellarg($path) . ' 2>&1';
            @exec($cmd, $o, $rc);
            if ($rc === 0 && is_file($path) && filesize($path) > 1024) {
                return ['ok' => true, 'path' => $path, 'error' => null, 'method' => 'mysqldump'];
            }
            @unlink($path);
        }
    }

    // 2) PDO fallback — schema + data, enough to restore.
    try {
        $db  = db();
        $fh  = fopen($path, 'w');
        if (!$fh) throw new RuntimeException('cannot open dump file');
        fwrite($fh, "-- HRMS database backup for {$deploymentId}\n-- " . date('c') . "\nSET FOREIGN_KEY_CHECKS=0;\n\n");
        foreach ($db->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) as $t) {
            $create = $db->query('SHOW CREATE TABLE `' . $t . '`')->fetch(PDO::FETCH_NUM)[1] ?? '';
            fwrite($fh, "DROP TABLE IF EXISTS `$t`;\n$create;\n\n");
            $rows = $db->query('SELECT * FROM `' . $t . '`');
            while ($r = $rows->fetch(PDO::FETCH_ASSOC)) {
                $vals = array_map(fn($v) => $v === null ? 'NULL' : $db->quote((string) $v), array_values($r));
                $cols = implode('`,`', array_keys($r));
                fwrite($fh, "INSERT INTO `$t` (`$cols`) VALUES (" . implode(',', $vals) . ");\n");
            }
            fwrite($fh, "\n");
        }
        fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
        fclose($fh);
        return ['ok' => true, 'path' => $path, 'error' => null, 'method' => 'pdo'];
    } catch (Throwable $e) {
        @unlink($path);
        error_log('deploy_db_backup failed: ' . $e->getMessage());
        return ['ok' => false, 'path' => null, 'error' => 'The database backup could not be created.', 'method' => 'none'];
    }
}

/**
 * Run one packaged .sql file. Only ever called after an explicit, separate
 * confirmation and a successful database backup.
 */
function deploy_run_sql(string $sqlText): array
{
    $out = ['ok' => false, 'statements' => 0, 'error' => null];
    // Strip line comments; keep statements intact.
    $clean = implode("\n", array_filter(preg_split('/\r?\n/', $sqlText),
             fn($l) => !preg_match('/^\s*(--|#)/', $l)));

    $db = db();
    try {
        foreach (array_filter(array_map('trim', explode(';', $clean))) as $stmt) {
            if ($stmt === '') continue;
            $db->exec($stmt);
            $out['statements']++;
        }
        $out['ok'] = true;
    } catch (Throwable $e) {
        error_log('deploy_run_sql failed: ' . $e->getMessage());
        $out['error'] = 'A statement failed. The database backup taken before this run can be restored.';
    }
    return $out;
}

// ─── Audit ────────────────────────────────────────────────────────────────────

/**
 * Record a deployment action in the existing activity log.
 * Never pass secrets in $extra — this is written to the database verbatim.
 */
function deploy_audit(string $action, string $deploymentId, string $summary, array $extra = []): void
{
    $desc = $deploymentId . ' — ' . $summary;
    if ($extra) $desc .= ' [' . http_build_query($extra, '', ', ') . ']';
    activity_log($action, 'Deployment', $desc);
}
