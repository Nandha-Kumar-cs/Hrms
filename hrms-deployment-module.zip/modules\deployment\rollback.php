<?php
/**
 * Roll a deployment back from its stored backup manifest.
 * Recorded as a new history event rather than by editing the original row.
 */
require_once __DIR__ . '/../../includes/bootstrap.php';
require_login();
require_permission('deployment', 'rollback');

$self = BASE_URL . '/modules/deployment/index.php';

if (!DEPLOYMENT_ENABLED) { flash('error', 'The deployment module is disabled.'); redirect($self); }
if (!is_super_admin())   { flash('error', 'Only a Super Admin can roll back a deployment.'); redirect($self); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect($self);
verify_csrf($_POST['csrf_token'] ?? '');

// Accept only our own id format — this value reaches the filesystem.
$deploymentId = trim((string) ($_POST['deployment_id'] ?? ''));
if (!preg_match('/^DEP-\d{8}-\d{6}$/', $deploymentId)) {
    flash('error', 'Invalid deployment reference.');
    redirect($self);
}

$db  = db();
$row = $db->prepare('SELECT * FROM deployments WHERE deployment_id = ? LIMIT 1');
$row->execute([$deploymentId]);
$dep = $row->fetch();

if (!$dep)                          { flash('error', 'That deployment does not exist.'); redirect($self); }
if ($dep['status'] === 'ROLLED_BACK') { flash('warn', 'That deployment has already been rolled back.'); redirect($self); }
if ($dep['status'] !== 'SUCCESS')    { flash('error', 'Only a successful deployment can be rolled back.'); redirect($self); }

$lock = deploy_lock();
if ($lock === null) {
    flash('error', 'A deployment is currently in progress. Please wait until it is completed.');
    redirect($self);
}

$maintOn = false;
// redirect() exits, which skips `finally` — register the cleanup instead.
deploy_register_cleanup($lock, $maintOn);

try {
    deploy_audit('ROLLBACK_STARTED', $deploymentId, 'Rollback requested');

    if (deploy_is_live()) { deploy_maintenance_enable(current_user()['name'] ?? 'admin'); $maintOn = true; }

    $r = deploy_rollback_deployment($deploymentId);

    // Deployment changed no files — mark it rolled back and say so plainly.
    if (!empty($r['nothing_to_do'])) {
        $db->prepare('UPDATE deployments SET status=?, rolled_back_at=NOW() WHERE deployment_id=?')
           ->execute(['ROLLED_BACK', $deploymentId]);
        deploy_audit('ROLLBACK_SUCCESS', $deploymentId, 'No files had been changed — nothing to restore');
        flash('info', $deploymentId . ' changed no files, so there was nothing to restore. '
            . 'It is now marked as rolled back.');
        redirect(BASE_URL . '/modules/deployment/details.php?id=' . urlencode($deploymentId));
    }

    if (!$r['ok']) {
        deploy_audit('ROLLBACK_FAILED', $deploymentId,
                     'Restored ' . $r['restored'] . ', failed ' . $r['failed']);
        flash('error', 'Rollback of ' . $deploymentId . ' was incomplete — '
            . $r['restored'] . ' file(s) restored, ' . $r['failed'] . ' could not be. '
            . 'The backup is still on disk; no further changes were made.');
        redirect(BASE_URL . '/modules/deployment/details.php?id=' . urlencode($deploymentId));
    }

    $db->prepare('UPDATE deployments SET status=?, rolled_back_at=NOW() WHERE deployment_id=?')
       ->execute(['ROLLED_BACK', $deploymentId]);
    $db->prepare('UPDATE deployment_files SET status=? WHERE deployment_id=? AND status=?')
       ->execute(['ROLLED_BACK', $deploymentId, 'OK']);

    deploy_audit('ROLLBACK_SUCCESS', $deploymentId, 'Restored ' . $r['restored'] . ' file(s)');
    flash('success', 'Rollback successful — ' . $r['restored'] . ' file(s) restored from '
        . $deploymentId . '.');
    redirect(BASE_URL . '/modules/deployment/details.php?id=' . urlencode($deploymentId));

} catch (Throwable $e) {
    error_log('Rollback ' . $deploymentId . ' error: ' . $e->getMessage());
    deploy_audit('ROLLBACK_FAILED', $deploymentId, 'Unexpected error during rollback');
    flash('error', 'Rollback of ' . $deploymentId . ' failed unexpectedly. The backup is still on disk.');
    redirect($self);
}
